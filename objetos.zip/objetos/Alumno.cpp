#include "Alumno.h"

tipoNota Alumno::getNotaFinal() {
    tipoNota notaFinal = 0;
    notaFinal = (0.3*hr1) + (0.3 * hr2) + (0.4 * pro1);
    return notaFinal;
}

Alumno::Alumno(entero codigo, const cadena &apellidos, const cadena &nombres, tipoNota hr1, tipoNota hr2, tipoNota pro1)
        : codigo(codigo), apellidos(apellidos), nombres(nombres), hr1(hr1), hr2(hr2), pro1(pro1)
{

}

Alumno::Alumno(entero codigo, const cadena &apellidos, const cadena &nombres) : codigo(codigo), apellidos(apellidos),
                                                                                nombres(nombres)
{

}

Alumno::~Alumno() {

}

entero Alumno::getCodigo() const {
    return codigo;
}

void Alumno::setCodigo(entero codigo) {
    Alumno::codigo = codigo;
}

const cadena &Alumno::getApellidos() const {
    return apellidos;
}

void Alumno::setApellidos(const cadena &apellidos) {
    Alumno::apellidos = apellidos;
}

const cadena &Alumno::getNombres() const {
    return nombres;
}

void Alumno::setNombres(const cadena &nombres) {
    Alumno::nombres = nombres;
}

tipoNota Alumno::getHr1() const {
    return hr1;
}

void Alumno::setHr1(tipoNota hr1) {
    Alumno::hr1 = hr1;
}

tipoNota Alumno::getHr2() const {
    return hr2;
}

void Alumno::setHr2(tipoNota hr2) {
    Alumno::hr2 = hr2;
}

tipoNota Alumno::getPro1() const {
    return pro1;
}

void Alumno::setPro1(tipoNota pro1) {
    Alumno::pro1 = pro1;
}

Alumno::Alumno()
{}
