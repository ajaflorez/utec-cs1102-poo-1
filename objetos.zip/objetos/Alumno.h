#ifndef OBJETOS_ALUMNO_H
#define OBJETOS_ALUMNO_H

#include <iostream>
#include <string>

using namespace std;

typedef int entero;
typedef string cadena;
typedef float tipoNota;

class Alumno {
private:
    entero codigo;
    cadena apellidos;
    cadena nombres;
    tipoNota hr1, hr2;
    tipoNota pro1;

public:

    tipoNota getNotaFinal();

    Alumno(entero codigo, const cadena &apellidos,
           const cadena &nombres, tipoNota hr1, tipoNota hr2,
           tipoNota pro1);
    Alumno(entero codigo, const cadena &apellidos,
           const cadena &nombres);

    Alumno();

    virtual ~Alumno();
    entero getCodigo() const;
    void setCodigo(entero codigo);
    const cadena &getApellidos() const;
    void setApellidos(const cadena &apellidos);
    const cadena &getNombres() const;
    void setNombres(const cadena &nombres);
    tipoNota getHr1() const;
    void setHr1(tipoNota hr1);
    tipoNota getHr2() const;

    void setHr2(tipoNota hr2);

    tipoNota getPro1() const;

    void setPro1(tipoNota pro1);
};

#endif //OBJETOS_ALUMNO_H
