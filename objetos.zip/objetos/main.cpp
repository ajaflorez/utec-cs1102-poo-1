#include <iostream>
#include "Alumno.h"

using namespace std;

int main() {
    Alumno carlos(201812345, "Chura", "Carlos");

    carlos.setHr1(12);
    carlos.setHr2(-9);
    carlos.setPro1(16);

    cout << carlos.getNotaFinal();

    // Punteros
    Alumno* jose;
    jose = new Alumno(201845632, "jose", "maquera");

    jose->setHr1(10);
    jose->setHr2(15);
    jose->setPro1(12);

    cout << jose->getNotaFinal();

    // Array
    Alumno lista[10];

    // Punteros
    Alumno* lista2;
    lista2 = new Alumno[10];


    // Array de Punteros
    Alumno** lista3;
    lista3 = new Alumno*[10];






    return 0;
}